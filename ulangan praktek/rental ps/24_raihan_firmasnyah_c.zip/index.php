<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>rental ps</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="login">
        <h3>login administrator</h3>
        <form action="proses.php" method="post">
            <!-- username -->
            <label for="username">username</label><br>
            <input type="text" id="username" name="username"><br>

            <!-- password -->
            <label for="password">password</label><br>
            <input type="password" id="password" name="password"><br>
            <button type="submit" class="button">loggin</button>
        </form>
    </div>
</body>

</html>