<link rel="stylesheet" href="style.css">
<nav class="wrapper">
    <div class="brand">
        <div class="fname">rental</div>
        <div class="lname">PS</div>
    </div>
    <ul class="navigation">
        <li><a href="#beranda">beranda</a></li>
        <li><a href="#paket">data paket</a></li>
        <li><a href="#tambah">tambah data</a></li>
        <li><a href="#">logout</a></li>
    </ul>
</nav>